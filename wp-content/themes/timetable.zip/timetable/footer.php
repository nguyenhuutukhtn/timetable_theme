<footer>
    <p>&copy; <?php echo date('Y'); ?>  | Author: Andrew Nguyen Huu Tu</p>
</footer>
<?php wp_footer(); ?>
 
</body>
</html>
